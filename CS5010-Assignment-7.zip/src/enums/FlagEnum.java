package enums;

/**
 * Types of flags supported.
 */
public enum FlagEnum {
  FRANCE, SWITZERLAND, GREECE
}
