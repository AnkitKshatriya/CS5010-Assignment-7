package enums;

/**
 * Types of color transformations supported.
 */
public enum TransformEnum {
  SEPIA, GREYSCALE
}
