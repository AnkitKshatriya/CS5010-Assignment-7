package enums;

/**
 * Type of filter operations supported.
 */
public enum FilterEnum {
  BLUR, SHARPEN
}
