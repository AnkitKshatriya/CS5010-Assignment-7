package enums;

/**
 * Type of dither algorithms supported.
 */
public enum DitherEnum {
  FS_DITHER, JJN_DITHER
}
