package enums;

/**
 * Type of Image input methods supported.
 */
public enum ImageFileEnums {
  FILE, URL
}
